Name: Dhananjay Kumar
Email: dhananjayandroid@gmail.com
Mobile: +91-8010026964
==================================


1. How to Build:
Import the project source code in Android studio as a new Android application. All the necessary files will be downloaded. If you face any issue try with Android Studio 2.3.1 and buildToolsVersion "25.0.1"

2. Install:
Copy the CashKaro-POC.apk file to your mobile device. Browse it with any file browser. Open it to install the app.


3. Use the app:
This application only works on devices running higher or equal to Android 5.0 (Lollipop) due to nested scrolling design to work properly and smoothly.
On home screen you can click on Carousel view and it will open the store page based on the Store selected.
Get Offer button on Home screen doesn't work.
In store page Shop now and Get Code button is working. If clicked it will open the store in webview with a backbutton to go back.
In Store page, user can click on Show Cashback Rates to see the details.
From drawer or topbar, user can go to the User section, where he/she can login with facebook id.
Camera and Location permissions can be obtained from respective option in the home drawer.

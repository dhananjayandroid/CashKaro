package com.dhananjay.cashkaro_poc.utils.bridges;

public interface LoadingBridge {

    void showProgress();

    void hideProgress();

}
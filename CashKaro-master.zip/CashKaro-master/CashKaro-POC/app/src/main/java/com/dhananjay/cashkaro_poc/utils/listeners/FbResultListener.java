package com.dhananjay.cashkaro_poc.utils.listeners;

import android.os.Bundle;

/**
 * Interface for Facebook result
 *
 * @author Dhananjay Kumar
 */

public interface FbResultListener {
    void onLoginResult(Bundle bundle);
}
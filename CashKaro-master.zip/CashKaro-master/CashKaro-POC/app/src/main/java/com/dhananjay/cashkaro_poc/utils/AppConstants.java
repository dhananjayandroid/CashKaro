package com.dhananjay.cashkaro_poc.utils;

/**
 * Created by Dhananjay on 18-04-2017.
 */
public class AppConstants {
    public static final String EXTRA_OFFER = "extra_offer";
    public static final String EXTRA_CATEGORY = "extra_category";
    public static final String EXTRA_NAME = "extra_name";
    public static final String EXTRA_EMAIL = "extra_email";
    public static final String REFRESH_USER_DETAILS = "refresh_user_details";
}
